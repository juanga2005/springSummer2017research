rm ./thrd41/solution/f*
rm ./thrd42/solution/f*
rm ./thrd43/solution/f*
rm ./thrd44/solution/f*
