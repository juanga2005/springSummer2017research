cd ./thrd41

./main/main > main.log &

cd ../thrd42

./main/main > main.log &

cd ../thrd43

./main/main > main.log &

cd ../thrd44

./main/main > main.log &

cd ..
