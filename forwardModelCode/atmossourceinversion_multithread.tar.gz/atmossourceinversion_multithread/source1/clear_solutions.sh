rm ./thrd11/solution/f*
rm ./thrd12/solution/f*
rm ./thrd13/solution/f*
rm ./thrd14/solution/f*
