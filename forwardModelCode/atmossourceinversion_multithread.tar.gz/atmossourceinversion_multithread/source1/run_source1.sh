
cd ./thrd11

./main/main > main.log &

cd ../thrd12

./main/main > main.log &

cd ../thrd13

./main/main > main.log &

cd ../thrd14

./main/main > main.log &

cd ..
