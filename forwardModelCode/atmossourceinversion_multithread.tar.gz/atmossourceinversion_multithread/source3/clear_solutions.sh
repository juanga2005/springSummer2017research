rm ./thrd31/solution/f*
rm ./thrd32/solution/f*
rm ./thrd33/solution/f*
rm ./thrd34/solution/f*
