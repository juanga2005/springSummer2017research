cd ./thrd31

./main/main > main.log &

cd ../thrd32

./main/main > main.log &

cd ../thrd33

./main/main > main.log &

cd ../thrd34

./main/main > main.log &

cd ..
