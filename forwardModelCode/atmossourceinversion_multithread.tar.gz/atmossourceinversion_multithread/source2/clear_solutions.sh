rm ./thrd21/solution/f*
rm ./thrd22/solution/f*
rm ./thrd23/solution/f*
rm ./thrd24/solution/f*
