cd ./thrd21

./main/main > main.log &

cd ../thrd22

./main/main > main.log &

cd ../thrd23

./main/main > main.log &

cd ../thrd24

./main/main > main.log &

cd ..
